#BY: "ROBOTHACEKRS"
red='\e[1;31m'
green='\e[1;32m'
blue='\e[1;34m'
purple='\e[1;35m'
cyan='\e[1;36m'
white='\e[1;37m'
yellow='\e[1;33m'
clear
echo -e $red "   R͓̽O͓̽B͓̽O͓̽T͓̽H͓̽A͓̽C͓̽A͓̽K͓̽R͓̽S͓̽"
echo ""
echo -e $red "1-"$white "MY YOU TUBE "
echo ""
echo -e $red "2-"$white "MY NUMPER WATSSAP"
echo ""
read -p "Enter The Number: " name
if [ $name = 1 ]
then
termux-open https://www.youtube.com/channel/UC68kmFZ4fznq_vEvDhvkGRg
fi
if [ $name = 2 ]
then
termux-open  https://wa.me/96891284402
fi

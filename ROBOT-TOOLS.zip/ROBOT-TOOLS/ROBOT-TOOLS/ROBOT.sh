#BY: ROBOT HACEKSR
#!bin/bash
#Whatsapp: 0096891284402
red='\e[1;31m'
green='\e[1;32m'
blue='\e[1;34m'
purple='\e[1;35m'
cyan='\e[1;36m'
white='\e[1;37m'
yellow='\e[1;33m'
echo -e $yellow{$red 1 $yellow} $green "VIRUS"
echo ''
echo -e $yellow{$red 2 $yellow} $green "WAping"
echo ''
echo -e $yellow{$red 3 $yellow} $green "VWS"
echo ''
echo -e $yellow{$red 4 $yellow} $green "virus Number💉"
echo ''
echo -e $yellow{$red 5 $yellow} $green "VIRUS Call📲💣"
echo ''
echo -e $white EXIT 00
echo ''
echo -e $purple
read -p "Enter The Number: " name
################ROBOTHACEKRS#################
if [ $name = 00 ]
then
clear
figlet ABDULLA
echo ""
echo -e $red    YOUTUBE :$blue "https://youtu.be/V2AvRlLLBe8"
echo ""
echo -e $red"    WHATSAPP: $green  0096891284402"
echo ""
echo -e $green"  BY:ROBOT HACEKRS"
echo ""
echo -e $red"      Good Bye !!"
exit
fi
################ROBOTHACEKRS#################
if [ $name = 1 ]
then
echo -e $white
read -p "What Is your Name: " name
echo $name > whatsapp.txt
echo "" >> whatsapp.txt
cat .VIRUS.txt >> whatsapp.txt
mkdir virus /whatsapp.txt
mv whatsapp.txt virus/whatsapp.txt
echo ''
echo -e $blue
read -p "Prease Enter To The Back" back
bash ROBOT.sh
fi
################ROBOTHACEKRS#################
if [ $name = 2 ]
then
echo -e $white
read -p "What Is your Name: " name
echo $name > WAping.txt
echo "" >> WAping.txt
cat .PING.txt >> WAping.txt
mkdir virus /WAping.txt
mv  WAping.txt virus/WAping.txt
echo ''
echo -e $blue
read -p "Prease Enter To The Back" back
bash ROBOT.sh
fi
################ROBOTHACEKRS#################
if [ $name = 3 ]
then
echo -e $white
read -p "What Is your Name: " name
echo $name > VWS.txt
echo "" >> VWS.txt
cat .SLEEP.txt >> VWS.txt
mkdir virus /VWS.txt
mv VWS.txt virus/VWS.txt
echo ''
echo -e $blue
read -p "Prease Enter To The Back" back
bash ROBOT.sh
fi
################ROBOTHACEKRS#################
if [ $name = 4 ]
then
echo -e $white
read -p "Number: " number
cd /data/data/com.termux/files/home/ROBOT-TOOLS/ROBOT-TOOLS/.Spammer-Grab
python2 spammer.py --delay 30 $number
fi
################ROBOTHACEKRS#################
if [ $name = 5 ]
then
echo -e $red
cd /data/data/com.termux/files/home/ROBOT-TOOLS/ROBOT-TOOLS/.fakecall
php call.php
fi

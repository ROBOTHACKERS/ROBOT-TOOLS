#BY: ROBOT HACEKRS
#GOOD INSTALL Metasploit
red='\e[1;31m'
green='\e[1;32m'
blue='\e[1;34m'
purple='\e[1;35m'
cyan='\e[1;36m'
white='\e[1;37m'
yellow='\e[1;33m'
clrar
echo  "install in metasploit"
sleep 1.0
clear
echo -e $white "[%5] ............................./"
sleep 1.0
clear
echo -e $white "[%10] ......................../"
sleep 1.0
clear
echo -e $white "[%20] ...................../"
sleep 1.0
clear
echo -e $white "[%40] .............../"
sleep 1.0
clear
echo -e $white "[%50] ............/"
sleep 1.0
clear
echo  -e $white "[%80] ........./"
sleep 1.0
clear
echo  -e $white "[%100] ...../"
sleep 1.0
clear
echo ".... DONE "
####################
curl -LO https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh

chmod +x metasploit.sh

bash metasploit.sh

cd metasploit-framework

bundle install rake-12.3.1

pip2 install bundler

bundle config build.nokogiri --use-system-libraries

gem install nokogiri

gem install pkg-config -v 12.3.1"

bundle install  rake-12.3.1
echo ""
echo ""
echo -e $white start metasploit [ N-Y ]
echo ""
echo -e $red
read -p "Enter The Number: " name
if [ $name = Y ]
then
msfconsole
fi
if [ $name = N ]
then
echo -e $red GOOD Bye
fi

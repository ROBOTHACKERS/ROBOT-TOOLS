#!bin/bash
#BY: ROBOT HACEKRS
#Whatsapp:0096891284402
#GOOD SRCIPT
red='\e[1;31m'
green='\e[1;32m'
blue='\e[1;34m'
purple='\e[1;35m'
cyan='\e[1;36m'
white='\e[1;37m'
yellow='\e[1;33m'
clear
apt update -y
apt upgrade -y
apt install git -y
apt install python2 -y
apt install python -y
apt install python3 -y
apt install wget -y
apt install curl -y
apt install perl -y
apt install proot -y
apt install figlet -y
apt install php -y
echo ""
echo -e $white BY : $red ROBOT HACEKRS
echo ""
echo -e $white WATSSAPP : $red 0096891284402
echo ""
echo ""
echo -e $red 1- $white ROBOT virus 
echo ""
echo -e $red 2- $white install metasploit
echo ""
echo -e $white 00 EXIT
echo ""
echo -e $purple
read -p "Enter The Number: " name
#####################
if [ $name = 00 ]
then
clear
figlet ABDULLA
echo ""
echo -e $red    YOUTUBE :$blue "https://youtu.be/V2AvRlLLBe8"
echo ""
echo -e $red"    WHATSAPP: $green  0096891284402"
echo ""
echo -e $green"  BY:ROBOT HACEKRS"
echo ""
echo -e $red"      Good Bye !!"
exit
fi
######################
if [ $name = 1 ]
then
clear
bash ROBOT.sh
fi
#####################
if [ $name = 2 ]
then
clear
bash MetaSploit-ROBOTHACEKRS.sh
fi
